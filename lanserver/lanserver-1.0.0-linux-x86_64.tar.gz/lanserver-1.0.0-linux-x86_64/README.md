# LAN Server

Share files with every browser on the local network, and take uploads from
them. One small Linux app (Rust + GTK4): the window is the host's side, and the
same program serves a web page that any phone, tablet or computer on the same
Wi-Fi/Ethernet opens with nothing installed.

## The window (host)

- **Hero banner**: the address(es) to open, e.g. `http://192.168.1.11:8080`,
  one per LAN interface (Wi-Fi / Ethernet), refreshed every few seconds, each
  with a copy button beside it (tooltip "Copy").
- **Hosting** (downloads): *Add* opens a file picker (several files at once), or
  drop files on the section. Only files are served; folders are skipped.
  Each file has a **Require permission**
  tick. Unticked files download straight away; ticked ones raise a request
  card (who, which browser, which file) with **Allow / Deny**. A desktop
  notification is sent too when the window is not in front. Downloads in
  progress show a bar under their file, and each file counts its downloads.
- **Received** (uploads): the **Require approval** switch (on by default). When it is on,
  every upload raises an Allow / Deny card *before* any bytes are sent. When it
  is off, uploads go straight through. Received files are listed with sender
  and time, and can be opened, shown in their folder, moved to **Hosting** with the ← arrow
  (served from where it was saved; it leaves Received), or taken off the list
  (the file stays). They land in `~/Downloads/LanServer` (XDG Downloads folder), and a
  taken name gets a number: `photo (2).jpg`.

- **Always the latest copy**: every download reads the file from disk as it
  is at that moment, so an edited file is sent in its new form. Hosted files
  are checked every 2 seconds; each shows when it was last updated (in the
  window and on the web page), its size follows edits, image previews are
  remade. A file deleted or moved away is taken off Hosting (the window
  says so), so browsers no longer see or download it.
- **Rename** (pencil on a Hosting file): changes the name browsers see and
  download it as. Only the name part is editable; the extension stays, and
  the file on disk keeps its real name (shown under a renamed file as
  `file: …`). *Original name* puts it back.
- **List or thumbnails**: each section has a List / Thumbnails switch in its
  head (remembered). Thumbnails are tiles: images show a preview (cached in
  `thumbs/` beside the state), other files a large type tile; in Hosting the
  "Require permission" box becomes a lock toggle. Browsers show the file list
  the way the host has Hosting set, picking up a change within a few seconds.
  A file that requires permission never has its preview sent to browsers
  (`/t/{id}` refuses it); they see its type tile with a lock.
- **Deleting several at once**: every row has a checkbox, and each section has
  **Select all** and **Delete** (after a confirmation). In Hosting this
  stops sharing; the files stay on disk. In Received it deletes the received
  files from disk permanently.

Unticking a file, or switching approval off, lets through anyone already waiting.

## The web page (clients)

`http://<address>:<port>/`: a file list with search, type badges and sizes;
**Download** for open files, **Ask to download** for the ones that need
permission. The button then waits ("Waiting for OK…", cancellable), and the download
starts by itself once allowed. A send panel takes picked or dropped files,
waits for approval when needed, and shows progress and speed. Light and dark
follow the device. No external resources, so it works with no internet.

## Network and safety

- Listens on every IPv4 interface on port 8080 (next free one up to 8099 if
  taken; the port is remembered). Connections from outside private, link-local
  and loopback ranges are dropped at the door.
- Downloads are addressed by id, never by path. A permission grant is a random
  128-bit ticket tied to the asking browser's address, good for 30 minutes
  (so a download can resume). Upload names are reduced to a bare file name,
  and the declared size must match what is sent. Partial uploads are written
  as hidden `.name.part` files and renamed only when complete.
- State (shared list, ticks, switch, port, received uploads):
  `~/.local/share/lanserver/state.json` (`$LANSERVER_HOME` overrides it, and
  then uploads go to `$LANSERVER_HOME/uploads`).

## Build and run

    cargo build --release        # needs libgtk-4-dev and pkg-config
    cp target/release/lanserver bin/
    ./bin/lanserver

`cargo test --no-default-features` builds and tests the server without GTK
(unit tests and end-to-end HTTP flows in `tests/flows.rs`).

Debug aids: `LANSERVER_THEME=dark|light`. In debug builds,
`LANSERVER_SCREENSHOT=dir LANSERVER_SHOTS=n` saves the window to PNGs every
1.5 s and then quits. `cargo run --example headless -- [port] [paths…]` runs the server
with no window and answers every request itself (anything named `*deny*` is
refused; shared paths named `*lock*` require permission), for driving the page
in a browser.

## Bundles for sharing

    packaging/build.sh

builds both into `dist/` (not committed):

- `lanserver-<version>-linux-x86_64.tar.gz`: any distro with GTK 4.14+.
  Unpack, then `./install.sh` (per user, no sudo: `~/.local/bin`, the
  icon, and a launcher so it shows in the app grid and dock). Remove it with
  `./uninstall.sh`, or just run `./lanserver` in place.
- `lanserver_<version>_amd64.deb`: Ubuntu 24.04+ / Debian 13+, installed
  with `sudo apt install ./lanserver_<version>_amd64.deb`, which pulls in GTK.

The icon is `src/web/icon.svg` (also the web page's). `cargo run --example
render_icon -- <dir>` renders the PNG sizes.

## Layout

    src/server.rs   state, requests/tickets, the HTTP routes, transfers
    src/http.rs     minimal HTTP/1.1 (keep-alive, Content-Length, ranges)
    src/net.rs      LAN addresses, who counts as local, tickets, browser names
    src/store.rs    state.json
    src/kinds.rs    file families, media types, sizes
    src/web/        the page (index.html) and icon, compiled into the binary
    src/ui/         the GTK window, its stylesheet, image previews
    packaging/      launcher, install/uninstall scripts, build.sh
