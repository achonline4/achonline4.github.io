#!/bin/sh
# Installs LAN Server for this user only (no sudo): the program in
# ~/.local/bin, its icon, and a launcher so it shows in the app grid and dock.
set -eu
here=$(cd "$(dirname "$0")" && pwd)
data="${XDG_DATA_HOME:-$HOME/.local/share}"
bin="$HOME/.local/bin"
apps="$data/applications"
icons="$data/icons/hicolor"

if ! ldconfig -p 2>/dev/null | grep -q 'libgtk-4\.so\.1'; then
    echo "Note: GTK 4 was not found. LAN Server needs GTK 4.14 or newer"
    echo "      (Ubuntu 24.04+: sudo apt install libgtk-4-1)."
fi

install -Dm755 "$here/lanserver" "$bin/lanserver"
for size in 16 24 32 48 64 128 256 512; do
    install -Dm644 "$here/icons/$size.png" "$icons/${size}x${size}/apps/com.abhishek.lanserver.png"
done
install -Dm644 "$here/icons/lanserver.svg" "$icons/scalable/apps/com.abhishek.lanserver.svg"
mkdir -p "$apps"
sed "s|@EXEC@|$bin/lanserver|" "$here/com.abhishek.lanserver.desktop.in" > "$apps/com.abhishek.lanserver.desktop"
chmod 644 "$apps/com.abhishek.lanserver.desktop"
gtk-update-icon-cache -q -t -f "$icons" 2>/dev/null || true
update-desktop-database -q "$apps" 2>/dev/null || true

echo "LAN Server is installed. Open it from the app grid (search \"LAN Server\");"
echo "right-click its icon in the dock and choose \"Pin to Dash\" to keep it there."
