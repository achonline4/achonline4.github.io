#!/bin/sh
# Removes what install.sh put in place. Your settings
# (~/.local/share/lanserver) and received files (~/Downloads/LanServer) stay.
set -eu
data="${XDG_DATA_HOME:-$HOME/.local/share}"
rm -f "$HOME/.local/bin/lanserver"
rm -f "$data/applications/com.abhishek.lanserver.desktop"
for size in 16 24 32 48 64 128 256 512; do
    rm -f "$data/icons/hicolor/${size}x${size}/apps/com.abhishek.lanserver.png"
done
rm -f "$data/icons/hicolor/scalable/apps/com.abhishek.lanserver.svg"
gtk-update-icon-cache -q -t -f "$data/icons/hicolor" 2>/dev/null || true
update-desktop-database -q "$data/applications" 2>/dev/null || true
echo "LAN Server has been removed. Settings and received files were kept."
