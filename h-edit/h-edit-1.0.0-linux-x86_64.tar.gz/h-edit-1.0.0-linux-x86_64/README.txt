H-Edit
======

Write, keep and find your records: text, tables, pictures, voice notes,
video and attached files, on a timeline that lives on your own computer.

- Every record is its own file, in a folder you choose (Settings, "Where things are kept").
  Nothing is sent anywhere.
- Export and import records as a zip.

Settings are kept in ~/.local/share/h-edit.

Voice notes and video use GStreamer (gst-launch-1.0 with the "good"
plugins) and parecord. Most desktops have them already; on Ubuntu:

    sudo apt install gstreamer1.0-tools gstreamer1.0-plugins-good pulseaudio-utils
