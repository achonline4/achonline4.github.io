#!/bin/sh
# Installs H-Edit for this user only, no sudo: the app into
# ~/.local/lib/h-edit, the command ~/.local/bin/h-edit, and the launcher and
# icon into the app grid. Run it from the unpacked folder.
set -eu
here=$(cd "$(dirname "$0")" && pwd)
share="${XDG_DATA_HOME:-$HOME/.local/share}"
dest="$HOME/.local/lib/h-edit"

if [ -e "$dest" ]; then
    rm -r "$HOME/.local/lib/h-edit"
fi
mkdir -p "$dest" "$HOME/.local/bin"
cp -r "$here/h-edit" "$here/data" "$here/lib" "$here/install-launcher.sh" "$dest/"
cp "$here/uninstall.sh" "$dest/"
ln -sf "$dest/h-edit" "$HOME/.local/bin/h-edit"
"$dest/install-launcher.sh"
echo "Installed in $dest. Start it from the app grid, or run: h-edit"
