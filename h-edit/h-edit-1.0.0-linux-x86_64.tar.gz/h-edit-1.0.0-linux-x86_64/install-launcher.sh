#!/usr/bin/env bash
# Puts H-Edit in the app grid and its icon on the dock: the icon in the
# user's icon theme, and a launcher in ~/.local/share/applications pointing at
# this folder. Run it again after moving the folder.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SHARE="${XDG_DATA_HOME:-$HOME/.local/share}"
ICONS="$HERE/data/icon"

# The icon by name, at every size the desktop asks for.
for size in 32 48 64 128 256; do
    mkdir -p "$SHARE/icons/hicolor/${size}x${size}/apps"
    cp "$ICONS/h-edit-$size.png" "$SHARE/icons/hicolor/${size}x${size}/apps/h-edit.png"
done
mkdir -p "$SHARE/icons/hicolor/512x512/apps" "$SHARE/icons/hicolor/scalable/apps"
cp "$ICONS/h-edit.png" "$SHARE/icons/hicolor/512x512/apps/h-edit.png"
cp "$ICONS/h-edit.svg" "$SHARE/icons/hicolor/scalable/apps/h-edit.svg"
touch "$SHARE/icons/hicolor"
command -v gtk-update-icon-cache >/dev/null 2>&1 &&
    gtk-update-icon-cache -q -t "$SHARE/icons/hicolor" 2>/dev/null || true

# The launcher, named for the app's id: that is how the dock knows the
# running window is this app.
mkdir -p "$SHARE/applications"
sed -e "s|^Exec=.*|Exec=\"$HERE/h-edit\"|" \
    "$ICONS/hedit.desktop" > "$SHARE/applications/hedit.desktop"
command -v update-desktop-database >/dev/null 2>&1 &&
    update-desktop-database "$SHARE/applications" >/dev/null 2>&1 || true

# The program file itself shows the icon in the file manager.
command -v gio >/dev/null 2>&1 &&
    gio set "$HERE/h-edit" metadata::custom-icon "file://$ICONS/h-edit.png" 2>/dev/null || true

echo "H-Edit is in the app grid, with its icon."
