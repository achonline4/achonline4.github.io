#!/bin/sh
# Removes what install.sh put in place. Your records and settings are kept:
# they live in the folder you chose and in ~/.local/share/h-edit.
set -eu
share="${XDG_DATA_HOME:-$HOME/.local/share}"

rm -f "$share/applications/hedit.desktop"
for size in 32x32 48x48 64x64 128x128 256x256 512x512; do
    rm -f "$share/icons/hicolor/$size/apps/h-edit.png"
done
rm -f "$share/icons/hicolor/scalable/apps/h-edit.svg"
command -v update-desktop-database >/dev/null 2>&1 &&
    update-desktop-database "$share/applications" >/dev/null 2>&1 || true
if [ -L "$HOME/.local/bin/h-edit" ]; then
    rm "$HOME/.local/bin/h-edit"
fi
if [ -d "$HOME/.local/lib/h-edit" ]; then
    rm -r "$HOME/.local/lib/h-edit"
fi
echo "H-Edit removed. Your records were left where they are."
